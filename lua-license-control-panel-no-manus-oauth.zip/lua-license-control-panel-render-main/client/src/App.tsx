import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import DashboardLayout from "@/components/DashboardLayout";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import SuperOwnerOverview from "@/pages/SuperOwnerOverview";
import SystemControl from "@/pages/SystemControl";
import AnnouncementControl from "@/pages/AnnouncementControl";

function Router() {
  return <Switch><Route path="/super-owner"><DashboardLayout><SuperOwnerOverview /></DashboardLayout></Route><Route path="/system-control"><DashboardLayout><SystemControl /></DashboardLayout></Route><Route path="/announcement-control"><DashboardLayout><AnnouncementControl /></DashboardLayout></Route><Route path="/"><DashboardLayout><Home /></DashboardLayout></Route><Route path="/404" component={NotFound} /><Route component={NotFound} /></Switch>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="dark"><TooltipProvider><Toaster /><Router /></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
